
const User=require("../models/user.model")
const jwt=require("jsonwebtoken")
require("dotenv").config()

const generateToken=(user)=>{
    return jwt.sign({user},process.env.SECRETE_KEY)
}


const register=async(req,res)=>{
    try {
        let user=await User.findOne({email:req.body.email})
        if(user){
            return res.status(400).send({message:"Email allready exist"})
        }
        user=await User.create(req.body)
        const token=generateToken(user)
    } catch (err) {
        req.status.send({message:err.message})
    }
}
const login=async (req,res)=>{
    try {
        let user=await User.findOne({email:req.body.email})
        if(!user){
            return res.status(400).send({message:"Wrong E-mail or password"})
        }
        const match=user.checkPassword(req.body.password)
        if(!match){
            return res.status(400).send({message:"Wrong E-mail or password"})
        }
        const token=generateToken(user)
        return res.status(400).send({user,token})
    } catch (err) {
        return res.status(400).send({message:err.message})
    }
}


module.exports={register,login}