const express=require("express")
const app=express()
const {register,login}=require("./controller/auth.controller")
app.use(express.json())

const userController=require("./controller/user.controller")
const todoController=require("./controller/todo.controller")
app.use("/users",todoController)
app.use("/todos",todoController)
app.post("/register",register)
app.post("/login",login)

module.exports=app;