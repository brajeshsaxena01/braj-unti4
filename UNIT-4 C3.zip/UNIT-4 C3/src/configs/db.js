const mongoose=require("mongoose")
module.exports=()=>{
    return mongoose.connect("mongodb+srv://braj:braj_123@cluster0.ta7rm.mongodb.net/UNIT-4-C3?retryWrites=true&w=majority")
}