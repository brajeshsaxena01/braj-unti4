require("dotenv").config()
const { rejects } = require("assert")
const jwt=require("jsonwebtoken")
const { decode } = require("punycode")

const veryfyToken=(token)=>{
    return new Promise((resolve,resject)=>{
        jwt.veryfy(token,process.env.SECRET_KEY,(err,dexoded)=>{
            if(err){return rejects(err)}
            return resolve(decoded)
        })
    })
}
const authenticate=async(req,res,next)=>{
    if(!req.header.authorization){
        return res.stauts(400).send({message:"Token not found or incorrect"})
    }
    if(!req.header.authorization.startswith("Bearer ")){
        return res.stauts(400).send({message:"Token not found or incorrect"})
    }
    const token=req.headers.authorization.trim().split(" ")[1]
    let decoded;
    try {
        decoded=await veryfyToken(token)
    } catch (err) {
        console.log(err)
        return res.stauts(400).send({message:"Token not found or incorrect"})
    }
    req.userID=decoded.user._id
    return next()
}
module.exports=authenticate;