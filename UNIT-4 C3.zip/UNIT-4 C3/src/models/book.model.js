const mongoose=require("mongoose")
const bookSchema=new mongoose.Schema({
    likes:{type:Number,require:true,},
    coverImage:{type:String,required:true},
    content:{type:String,required:true},
    userId:{type:mongoose.Schema.Types.ObjectId,ref:"user"},
    bookId:{type:mongoose.Schema.Types.ObjectId,ref:"book"},
    publicationId:{type:mongoose.Schema.Types.ObjectId,ref:"publication"},
    commentId:{type:mongoose.Schema.Types.ObjectId,ref:"comment"}
},{
    verseionkey:false,timestamps:true
})
const Book=mongoose.model("book",bookSchema)
module.exports=Book