const mongoose=require("mongoose")
const commentSchema=new mongoose.Schema({
    body:{type:String,required:true},
    userId:{type:mongoose.Schema.Types.ObjectId,ref:"user"},
    commentId:{type:mongoose.Schema.Types.ObjectId,ref:"comment"}
},{
    verseionkey:false,timestamps:true
})
const Comment=mongoose.model("comment",commentSchema)
module.exports=Comment