const mongoose= require("mongoose");
module.exports=()=>{
    return mongoose.connect("mongodb+srv://braj:braj_123@cluster0.ta7rm.mongodb.net/myFirstDatabase?retryWrites=true&w=majority") 
}