const express=require("express")
const userController=require("./controller/user.controller")
const bookController=require("./controller/book.controller")
const commentController=require("./controller/comment.controller")
const app= express()
app.use("user",userController)
app.use("comment",commentController)
app.use("book",bookController)
app.use(express.json())

module.exports=app;